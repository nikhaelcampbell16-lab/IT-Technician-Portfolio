const express = require('express');
const bodyParser = require('body-parser');

const app = express();
app.use(bodyParser.urlencoded({ extended: true })); // To parse HTML form bodies

// Serve static files so we can use CSS/HTML
app.use(express.static(__dirname));

// Main page
app.get('/', function (req, res) {
  res.sendFile(__dirname + '/index.html');
});

// Display the information when there is post request
app.post('/', async function (request, response) {
  const city = (request.body.city || '').trim();
  if (!city) {
    return response.status(400).send({ error: 'City is required' });
  }

  const url = new URL('https://community-open-weather-map.p.rapidapi.com/weather');
  url.search = new URLSearchParams({
    q: city,
    lang: 'en',
    units: 'imperial',
  });

  // Update your API key
  const headers = {
    'x-rapidapi-key': 'b0ecde0aa7msh4000c55386b3d0ap1a619djsn5b8ac1b1b077',
    'x-rapidapi-host': 'community-open-weather-map.p.rapidapi.com',
    useQueryString: 'true',
  };

  try {
    const apiRes = await fetch(url.toString(), { headers });
    const data = await apiRes.json();

    if (!apiRes.ok) {
      return response.status(apiRes.status).send(data);
    }

    response.send(data);
  } catch (err) {
    console.error('Weather API request failed', err);
    response.status(500).send({ error: 'Failed to fetch weather data' });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

const port = process.env.PORT || 8002;
app.listen(port, function () {
  console.log(`Server running on port ${port}`);
});
