from django.shortcuts import render
from .models import Contact

def index(request):
    return render(request, 'labassignment/index.html')

def help_page(request):
    return render(request, 'labassignment/help.html')

def contacts(request):
    contact_list = Contact.objects.order_by('first_name')
    contact_dict = {'contacts': contact_list}
    return render(request, 'labassignment/contacts.html', context=contact_dict)