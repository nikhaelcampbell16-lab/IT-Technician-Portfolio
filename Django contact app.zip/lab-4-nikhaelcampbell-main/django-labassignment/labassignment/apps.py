from django.apps import AppConfig


class LabassignmentConfig(AppConfig):
    name = 'labassignment'
