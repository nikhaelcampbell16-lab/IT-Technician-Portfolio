# Lab-4

1. Build a Django contacts app from scratch.
2. Start your project.
3. Create your app. Name it as you like.
4. Create your templates folder.
    1. Create your app folder under templates and create index.html, contacts.html, help.html files there. You can use an HTML boilerplate for now.
5. In settings.py update
    1. TEMPLATES -> DIRS
        1. Add your directory
    2. INSTALLED_APPS
        1. Add your app name
6. Update your models.py
7. Update your views.py to include html files
    1. Tip:

    ```python
    #import necessary models
    #include necessary html files

    def contacts(request):
    	contact_list = Contact.objects.order_by('first_name')
    	contact_dict = {'contacts':contact_list}
    	return render(request, 'appname/index.html', context=contact_dict)

    # complete the code
    ```

8. Update urls.py
9. Do the migration. Necessary updates for the database.
10. Do the necessary updates to be able to use the admin interface
11. Add a couple of contacts using admin interface
12. Update your index.html, help.html and contacts.html
    1. Contacts.html should list your contacts.
    2. The help page should explain the site's functionality.
    3. The index page should have a greeting and links to the contacts and help pages.
    4. Use CSS to style your pages.
    5. Get creative.
13. Display those files
    1. localhost:8000/ (for index.html)
    2. localhost:8000/help/
    3. localhost:8000/contacts/
14. Add screenshots for each of the steps into your repository
15. Update the **readme file** by answering the following questions and typing your answers in that file.
    1. Explain your steps and include screenshots if needed.
    # Django Contacts App

## Project Overview
This project is a Django web application that allows users to store and display contacts. The application includes a home page, a help page, and a contacts page. Contacts are stored in the database and managed through the Django admin interface.

## Steps I Completed
1. Installed Django in a virtual environment.
2. Created a Django project called `myproject`.
3. Created an app called `contactsapp`.
4. Created template files: `index.html`, `contacts.html`, and `help.html`.
5. Updated `settings.py` by:
   - Adding `contactsapp` to `INSTALLED_APPS`
   - Updating the `TEMPLATES` `DIRS` setting
6. Created a `Contact` model in `models.py`.
7. Updated `views.py` to render all pages and send contacts to the contacts template.
8. Created `urls.py` in the app and connected it in the project `urls.py`.
9. Ran migrations to update the database.
10. Registered the `Contact` model in `admin.py`.
11. Created a superuser and added contacts through the Django admin interface.
12. Styled the pages using CSS.
13. Tested all pages in the browser.

16. Submit your repository via github.
